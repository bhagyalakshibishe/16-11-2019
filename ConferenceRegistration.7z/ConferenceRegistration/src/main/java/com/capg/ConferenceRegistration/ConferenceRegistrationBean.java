package com.capg.ConferenceRegistration;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

public class ConferenceRegistrationBean {
	WebDriver driver;
	@FindBy(id = "txtFirstName")
	WebElement firstName;
	@FindBy(id = "txtLastName")
	WebElement lastName;
	@FindBy(id = "txtEmail")
	WebElement email;
	@FindBy(id = "txtPhone")
	WebElement contactNo;
	@FindBy(name = "size")
	WebElement noOfPeople;
	@FindBy(id = "txtAddress1")
	WebElement building;
	@FindBy(id = "txtAddress2")
	WebElement area;
	@FindBy(name = "city")
	WebElement city;
	@FindBy(name = "state")
	WebElement state;
	@FindBy(name = "memberStatus")
	List<WebElement> memberstatus;
	@FindBy(linkText="Next") 
	WebElement nextLink;
	
	public ConferenceRegistrationBean(WebDriver btn) {
		driver = btn;
		PageFactory.initElements(driver, this);
	}

	public String getFirstName() {
		return firstName.getAttribute("value");
	}

	public void setFirstName(String firstName) {
		this.firstName.sendKeys(firstName);
	}

	public String getLastName() {
		return lastName.getAttribute("value");
	}

	public void setLastName(String lastName) {
		this.lastName.sendKeys(lastName);
	}

	public String getEmail() {
		return email.getAttribute("value");
	}

	public void setEmail(String email) {
		this.email.clear();
		this.email.sendKeys(email);
	}
   
	public String getContactNo() {
		return contactNo.getAttribute("value");
	}

	public void setContactNo(String contactNo) {
		this.contactNo.clear();
		this.contactNo.sendKeys(contactNo);;
	}

	

	public int getNoOfPeople() {
		return Integer.parseInt(new Select(this.noOfPeople).getFirstSelectedOption().getText());
	}

	public void setNoOfPeople(String noOfPeople) {
		new Select(this.noOfPeople).selectByVisibleText(noOfPeople);
	}
	
	public String getBuilding() {
		return building.getAttribute("value");
	}

	public void setBuilding(String building) {
		this.building.sendKeys(building);
	}

	public String getArea() {
		return area.getAttribute("value");
	}

	public void setArea(String area) {
		this.area.sendKeys(area);;
	}

	public int getCity() {
		return Integer.parseInt(new Select(this.city).getFirstSelectedOption().getText());
	}

	public void setCity(String city) {
		new Select(this.city).selectByVisibleText(city);
	}

	public int getState() {
		return Integer.parseInt(new Select(this.state).getFirstSelectedOption().getText());
	}

	public void setState(String state) {
		new Select(this.state).selectByVisibleText(state);
	}
	
	public void clickNextPageLink( ) {
		this.nextLink.click();
	}

	public String getMemberstatus() {
		for(WebElement webElement : this.memberstatus) 
			if(webElement.isSelected())
				return webElement.getAttribute("value");
			return null;
	}

	public void setMemberstatus(String memberstatus) {
		if(memberstatus.equals("member")) 
		 this.memberstatus.get(1).click();
		else if(memberstatus.equals("non-member"))
			this.memberstatus.get(0).click();
	}

	

//	public String getMemberstatus() {
//		for(WebElement webElement : memberstatus) 
//			if(webElement.isSelected())
//				return webElement.getAttribute("value");
//			return null;
//			
//	}
//
//	public void setMemberstatus(String memberstatus) {
//		if(memberstatus.equals("member")) 
//			((WebDriver) this.memberstatus).get(1).click();
//		else if(memberstatus.equals("non-member"))
//			this.memberstatus.get(0).click();
//	}
	
	
	
}
